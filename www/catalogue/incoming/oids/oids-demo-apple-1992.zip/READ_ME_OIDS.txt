
Oids is a 5 Mice, award-winning (Mac User Magazine; June 1991) arcade action game that you won't be able to stop playing!

Your task is to pilot a V-wing fighter craft through a gauntlet of Biocrete defenses to rescue an exploited race of mechanical beings called Oids.  Deftly avoid the deadly subterranean bases, or just blow the heck out of them?  You choose.  But remember, get in fast and get out faster because rescue is the mission here.

When you've mastered the numerous  multi-planet Galaxies provided on the game disk (each one is a complete game within a game!) you can switch to the OIDS editor and design your own games.  Designing your own Galaxy is as simple as clicking on a tool and painting in the details.  Your can even trade your designs with your friends or collect and play the dozens now available from on-line services.

And, it works on all Macs.  Black & White and color!

OIDS Demo:

Double click on OIDS demo icon to launch the demo.  The demo is self-running for 2-3 minutes then gives you the option of trying your hand at the game.  On-screen messages explain the game controls.

Suggested retail:  $44.95

Available at local Mac software retailers and the following mail order retailers:

	Mac Connection			(800) 800-2222
	Mac Warehouse			(800) 255-6227
	Mac Zone								(800) 248-0800
	Mac's Place						(800) 367-4222
	Computer Ware			(800) 326-0092

or contact us directly at:

	FTL Games
	6160 Lusk Blvd. Suite C-102
	San Diego, CA  92121
	Tel. (619) 453-5711
	Fax (619) 453-5716
	Apple Link D1428

